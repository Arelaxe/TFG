package enumerate;

public enum Position {
	 Ground_Ground,
	 Ground_Air,
	 Air_Ground,
	 Air_Air
}
